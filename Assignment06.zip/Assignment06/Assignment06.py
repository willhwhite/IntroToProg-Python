# --Processing-- #
class ToDoList(object):
    listMaster = []  # Create a blank list to store our dictionaries

    # Method that takes a string for a task and a string for priority and adds a new line to our to do list
    def newLine(self, newTask, newPriority):
        newDict = {"Task": newTask, "Priority": newPriority}
        self.listMaster.append(newDict)

    # Method to read data from ToDo.txt and add it to our to do list
    def loadData(self):
        fileRead = open("C:\_PythonClass\ToDo.txt", "r")  # Open the ToDo.txt file
        fileContent = [clearSpaces.strip() for clearSpaces in fileRead]  # Remove blank spaces

        for line in fileContent:  # Loop through the file data and separate the data into elements at each comma
            strRow = line.split(",")
            self.newLine(strRow[0], strRow[1])

        fileRead.close()  # Close the file

    # Method to print out the to do list to the user
    def printTaskList(self):  # Create a function to show current data
        print("These are the current items in your list: ")
        for row in self.listMaster:
            print(self.listMaster.index(row) + 1, row["Task"], ",", row["Priority"])

    # Method that accepts a integer representing the row number of a to do item and removes that element from the to do list
    def removeItem(self, rowNumber):  # Create a function to remove an existing item
        listIndexValue = self.listMaster[rowNumber - 1]
        self.listMaster.remove(listIndexValue)

    # Method that saves the to do list to ToDo.txt
    def saveData(self):  # Create a function to save data to file
        fileWrite = open("C:\_PythonClass\ToDo.txt", "w")  # Open the ToDo.txt file
        for row in self.listMaster:
            fileWrite.write(row["Task"] + "," +row["Priority"]+"\n")
        fileWrite.close()


# --Presentation-- #
objMyList = ToDoList()  # Create a ToDoList instance
objMyList.loadData()  # Call the method loadData to read the toDo.txt and load the current data into a list

menuSelection = 1   # Start with menu option one being selected, which will print out our current to do list
while True:  # Loop through the menuSelection options to match the users input and call the appropriate function

    menuSelection = int(menuSelection)  # Turn the user's menu selection into an integer to test

    if menuSelection == 1:              # Print out the to do list if the user selected option #1
        objMyList.printTaskList()

    elif menuSelection == 2:   # Prompt the user for a task/priority and add a new line to the to do list for #2
        newTask = input("Enter the name of your task: ")
        newPriority = input("Enter the task's priority: ")
        objMyList.newLine(newTask, newPriority)

    elif menuSelection == 3:            # Ask the user to select a line number of the to do list to remove
        indexValue = input("Enter the row number you would like to remove: ")
        objMyList.removeItem(int(indexValue))

    elif menuSelection == 4:            # Save the current to do list back to toDo.txt
        objMyList.saveData()
        print("Your data has been saved")

    elif menuSelection == 5:        # save and exit the program if the user selects option #5
        objMyList.saveData()
        break

    # Prompt the user to select another menu option if they did not select to exit the program.
    menuSelection = input("\nSelect an option from the below menu:\n"+
    "1) Show current data\n"+
    "2) Add a new item\n"+
    "3) Remove an existing item\n"+
    "4) Save Data to File\n"+
    "5) Exit Program\n")