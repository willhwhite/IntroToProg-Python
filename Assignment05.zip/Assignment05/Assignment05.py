'''
1.	Create a text file called ToDo.txt using the following data:
Clean House,low
Pay Bills,high
2.	When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary. (The data will be stored like a row in a table.)
Tip: You can use a for loop to read a single line of text from the file and then place the data into a new dictionary object.
3.	After you get the data in a Python dictionary, Add the new dictionary “row” into a Python list object (now the data will be managed as a table).
4.	Display the contents of the List to the user.
5.	Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
6.	Save the data from the table into the ToDo.txt file when the program exits.
Tip: I have provided a starting template to help you organize your code and help with some of the coding. You can use it or create your own file from scratch, but you have a lot of work to do in this module so, you may want to take advantage of the help.
'''

# --Data-- #
listMaster = []  # Create a blank list to store our dictionaries


# --Processing-- #
def printTaskList():  # Create a function to show current data
    print("These are the current items in your list: ")
    for row in listMaster:
        print(listMaster.index(row) + 1, row["Task"],",", row["Priority"])


def newLine(newTask, newPriority):  # Create a function to add a new item
    newDict = {"Task": newTask, "Priority": newPriority}
    listMaster.append(newDict)


def removeItem(rowNumber):  # Create a function to remove an existing item
    listIndexValue = listMaster[rowNumber - 1]
    listMaster.remove(listIndexValue)


def saveData():  # Create a function to save data to file
    fileWrite = open("C:\_PythonClass\ToDo.txt", "w")  # Open the ToDo.txt file
    for row in listMaster:
        fileWrite.write(row["Task"] +","+row["Priority"]+"\n")
    fileWrite.close()


# --Presentation-- #
fileRead = open("C:\_PythonClass\ToDo.txt", "r")  # Open the ToDo.txt file
fileContent = [clearSpaces.strip() for clearSpaces in fileRead]  # Remove blank spaces

for line in fileContent:  # Loop through the file data and separate the data into elements at each comma
    strRow = line.split(",")
    newLine(strRow[0], strRow[1])

fileRead.close()  # Close the file

menuSelection = 1
while True:  # Loop through the menuSelection options to match the users input and call the appropriate function
    menuSelection = int(menuSelection)
    if menuSelection == 1:
        printTaskList()
    elif menuSelection == 2:
        newTask = input("Enter the name of your task: ")
        newPriority = input("Enter the task's priority: ")
        newLine(newTask, newPriority)
    elif menuSelection == 3:
        indexValue = input("Enter the row number you would like to remove: ")
        removeItem(int(indexValue))
    elif menuSelection == 4:
        saveData()
        print("Your data has been saved")
    elif menuSelection == 5:
        saveData()
        break

    menuSelection = input("\nSelect an option from the below menu:\n"+
    "1) Show current data\n"+
    "2) Add a new item\n"+
    "3) Remove an existing item\n"+
    "4) Save Data to File\n"+
    "5) Exit Program\n")